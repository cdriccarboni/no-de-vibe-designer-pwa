// Compositeur Scénographique Temps Réel Multi-layers
// No[co]de Vibe Designer — Rendu d'ensemble des pistes Timeline, personnages et post-FX

import { TimelineClip, TimelineTrack, ReusableScenicElement } from '../types/timeline';
import { generateSyntheticPiratePose, renderPirateShadowCanvas } from './scenographyEngine';
import { scenicAudio } from './scenicAudioEngine';
import { SkeletonPose } from '../types/scenography';

export interface ScenicCompositorState {
  lastFootstepTime: number;
  slitScanBuffer: HTMLCanvasElement | null;
  trailsBuffer: HTMLCanvasElement | null;
}

export const compositorState: ScenicCompositorState = {
  lastFootstepTime: 0,
  slitScanBuffer: null,
  trailsBuffer: null
};

export function renderScenicStage(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  currentTimeSec: number,
  clips: TimelineClip[],
  tracks: TimelineTrack[],
  library: ReusableScenicElement[],
  isPlaying: boolean
) {
  // 1. FOND SCÉNIQUE DU PLATEAU DE THÉÂTRE (Sombre #101214 avec repères de régie)
  ctx.save();
  ctx.fillStyle = '#0c0e11';
  ctx.fillRect(0, 0, width, height);

  // Gradient vertical d'ambiance scénique (projecteurs face doux)
  const stageGrad = ctx.createLinearGradient(0, 0, 0, height);
  stageGrad.addColorStop(0, 'rgba(18, 22, 28, 0.9)');
  stageGrad.addColorStop(0.65, 'rgba(12, 14, 18, 0.95)');
  stageGrad.addColorStop(1, 'rgba(6, 8, 10, 1.0)');
  ctx.fillStyle = stageGrad;
  ctx.fillRect(0, 0, width, height);

  // Ligne de sol scénique et repères de plateau (Jardin / Centre / Cour)
  const floorY = height * 0.72;
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, floorY);
  ctx.lineTo(width, floorY);
  ctx.stroke();

  // Repères discrets de plateau
  ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.font = '9px monospace';
  ctx.fillText('JARDIN [0.20]', width * 0.18, floorY + 16);
  ctx.fillText('CENTRE [0.50]', width * 0.47, floorY + 16);
  ctx.fillText('COUR [0.80]', width * 0.78, floorY + 16);

  ctx.restore();

  // Filtrer les clips actifs à l'instant T de la timeline
  const activeClips = clips.filter((clip) => {
    if (!clip.active) return false;
    const track = tracks.find((t) => t.id === clip.trackId);
    if (!track || track.isMuted) return false;
    return currentTimeSec >= clip.startTime && currentTimeSec <= clip.startTime + clip.duration;
  });

  // Trier par numéro de layer (Layer 1 au fond, Layer 4 au dessus)
  activeClips.sort((a, b) => {
    const trackA = tracks.find((t) => t.id === a.trackId);
    const trackB = tracks.find((t) => t.id === b.trackId);
    return (trackA?.layerNumber || 1) - (trackB?.layerNumber || 1);
  });

  // Détection de post-effets globaux à appliquer
  let hasSlitScan = false;
  let slitScanIntensity = 0.5;
  let hasRgbSplit = false;
  let rgbSplitIntensity = 0.5;
  let hasAnaglyph = false;

  // 2. RENDU DE CHAQUE CLIP ACTIF
  for (const clip of activeClips) {
    const element = library.find((e) => e.id === clip.elementId);
    const track = tracks.find((t) => t.id === clip.trackId);
    const layerOpacity = track ? track.opacity : 1.0;

    // Calcul de la progression relative dans le clip (0..1)
    const clipLocalTime = currentTimeSec - clip.startTime;

    // A. ÉLÉMENT OMBRE DU PIRATE OU PERSONNAGE SILHOUETTE
    if (!element || element.type === 'performer_shadow' || clip.elementId === 'elem-pirate-shadow' || clip.elementId === 'elem-compound-pirate-echo') {
      // Déterminer la cinématique selon l'instant du clip
      let poseMode: 'idle_jardin' | 'walk_to_center' | 'sword_duel' | 'pirate_dance' = 'idle_jardin';
      let currentX = clip.transform.x;

      if (clip.animationMode === 'mirror') {
        poseMode = 'walk_to_center';
        currentX = 0.32;
      } else if (clip.animationMode === 'autonomous') {
        poseMode = 'pirate_dance';
        // Traversée de scène si configurée
        const cycle = (clipLocalTime * clip.motionSpeed) % 8;
        currentX = 0.35 + Math.sin(cycle * 0.7) * 0.28;
      } else {
        // Mode Hybride : alterne miroir et danse
        const isMirrorPhase = (Math.floor(clipLocalTime / 4) % 2) === 0;
        poseMode = isMirrorPhase ? 'walk_to_center' : 'pirate_dance';
        currentX = isMirrorPhase ? 0.35 : 0.55 + Math.sin(clipLocalTime * 1.2) * 0.15;
      }

      // Synthèse de la pose avec cinématique directe
      const pose = generateSyntheticPiratePose(clipLocalTime, poseMode, clip.motionSpeed);

      // Détection des impacts de pas pour audio synchrone
      if (isPlaying && clip.audioConfig.enabled && clip.audioConfig.reactiveToSteps) {
        const leftAnkleY = pose.leftAnkle.y;
        const rightAnkleY = pose.rightAnkle.y;
        const isStepContact = leftAnkleY > 0.88 || rightAnkleY > 0.88;
        const nowMs = performance.now();
        if (isStepContact && nowMs - compositorState.lastFootstepTime > 260) {
          compositorState.lastFootstepTime = nowMs;
          scenicAudio.triggerFootstep(90, clip.audioConfig.volume);
        }
      }

      // Rendu de la silhouette sur le canvas avec ses attributs réels
      renderPirateShadowCanvas(
        ctx,
        pose,
        {
          ...clip.transform,
          x: currentX,
          opacity: clip.transform.opacity * layerOpacity
        },
        element?.costume || {
          hatType: 'tricorn',
          hasSashBelt: true,
          hasCutlassSabre: true,
          hasCoatFlaps: true,
          featherAngle: -25
        },
        width,
        height,
        {
          color: '#15191f',
          glowColor: 'rgba(215, 184, 106, 0.45)', // Lueur ambre No[co]de
          glowBlur: 16
        }
      );
    }

    // B. ÉLÉMENT CHAT DE LUMIÈRE
    else if (element?.type === 'light_creature' && clip.elementId === 'elem-light-cat') {
      renderScenicLightCat(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity,
        isPlaying
      );
    }

    // C. ÉLÉMENT BALEINE INTERACTIVE
    else if (element?.type === 'light_creature' && clip.elementId === 'elem-whale') {
      renderScenicWhale(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // D. DANSEUR SPECTRAL (PEPPER'S GHOST)
    else if (clip.elementId === 'elem-dancer-ghost' || clip.visualFx === 'peppers_ghost') {
      renderScenicDancerGhost(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // E. PANTIN DE FILS (MARIONNETTE VIRTUELLE)
    else if (clip.elementId === 'elem-wire-puppet' || clip.motionStyle === 'wire_marionette') {
      renderScenicWirePuppet(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // F. BANC DE MÉDUSES FLUORESCENTES
    else if (clip.elementId === 'elem-jellyfish-swarm' || element?.iconType === 'jellyfish') {
      renderScenicJellyfish(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // G. NUÉE D'OISEAUX BOIDS / PARTICULES LUMINEUSES
    else if (clip.elementId === 'elem-particle-boids' || clip.visualFx === 'particle_boids') {
      renderScenicBoids(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // H. BRASIER NUMÉRIQUE & BRAISES
    else if (clip.elementId === 'elem-fire-braziers' || element?.iconType === 'fire') {
      renderScenicFireBraziers(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // I. MIROIR D'EAU & ONDES RÉFRACTIVES
    else if (clip.elementId === 'elem-water-ripples' || clip.visualFx === 'water_ripples') {
      renderScenicWaterRipples(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // J. BRUME VOLUMÉTRIQUE DE PLATEAU
    else if (clip.elementId === 'elem-fog-volumetric' || clip.visualFx === 'fog_volumetric') {
      renderScenicVolumetricFog(
        ctx,
        width,
        height,
        clipLocalTime,
        clip,
        layerOpacity
      );
    }

    // DÉTECTION DES POST-EFFETS VISUELS GLOBAUX
    if (clip.visualFx === 'slit_scan' || element?.visualFx === 'slit_scan') {
      hasSlitScan = true;
      slitScanIntensity = clip.fxIntensity || 0.75;
    }
    if (clip.visualFx === 'rgb_split' || element?.visualFx === 'rgb_split') {
      hasRgbSplit = true;
      rgbSplitIntensity = clip.fxIntensity || 0.65;
    }
    if (clip.visualFx === 'anaglyph' || element?.visualFx === 'anaglyph') {
      hasAnaglyph = true;
    }
    if (clip.visualFx === 'hydra_feedback') {
      applyHydraFeedbackEffect(ctx, width, height, currentTimeSec, clip.fxIntensity || 0.8);
    }
    if (clip.visualFx === 'vortex_tunnel') {
      applyVortexTunnelEffect(ctx, width, height, currentTimeSec, clip.fxIntensity || 0.85);
    }
  }

  // 3. POST-TRAITEMENT VISUEL (Slit-Scan, RGB Split, Anaglyphe)
  if (hasSlitScan) {
    applySlitScanEffect(ctx, width, height, currentTimeSec, slitScanIntensity);
  }
  if (hasRgbSplit || hasAnaglyph) {
    applyRgbSplitEffect(ctx, width, height, rgbSplitIntensity, hasAnaglyph);
  }
}

/**
 * Dessine le Chat de lumière stylisé avec cinématique féline et traînées néon
 */
function renderScenicLightCat(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number,
  isPlaying: boolean
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x;
  const cy = height * clip.transform.y;
  const s = clip.transform.scale * 0.9;

  ctx.translate(cx, cy);
  if (clip.transform.flipHorizontal) ctx.scale(-1, 1);

  // Cinématique 4 pattes
  const legFL = Math.sin(t * 3.5);
  const legFR = -Math.sin(t * 3.5);
  const legBL = -Math.sin(t * 3.5 + 0.4);
  const legBR = Math.sin(t * 3.5 + 0.4);

  // Détection audio de pas félin
  if (isPlaying && clip.audioConfig.enabled && clip.audioConfig.reactiveToSteps) {
    if (Math.abs(legFL) > 0.92) {
      scenicAudio.triggerSparkle(660 + Math.sin(t) * 120, clip.audioConfig.volume * 0.4);
    }
  }

  // Lueur néon
  ctx.shadowColor = '#38bdf8';
  ctx.shadowBlur = 18;
  ctx.strokeStyle = '#38bdf8';
  ctx.fillStyle = '#0284c7';
  ctx.lineWidth = 3 * s;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // 1. Corps félin arqué
  ctx.beginPath();
  ctx.ellipse(0, 0, 48 * s, 22 * s, 0, 0, Math.PI * 2);
  ctx.stroke();

  // 2. Tête et museau
  ctx.beginPath();
  ctx.arc(42 * s, -14 * s, 16 * s, 0, Math.PI * 2);
  ctx.stroke();

  // Oreilles triangulaires pointues
  ctx.beginPath();
  ctx.moveTo(34 * s, -26 * s);
  ctx.lineTo(40 * s, -42 * s);
  ctx.lineTo(46 * s, -28 * s);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(46 * s, -28 * s);
  ctx.lineTo(54 * s, -42 * s);
  ctx.lineTo(58 * s, -24 * s);
  ctx.stroke();

  // Yeux félins lumineux
  ctx.fillStyle = '#d7b86a';
  ctx.shadowColor = '#d7b86a';
  ctx.beginPath();
  ctx.arc(46 * s, -16 * s, 3 * s, 0, Math.PI * 2);
  ctx.fill();

  // 3. Pattes articulées
  const drawLeg = (baseX: number, phaseVal: number) => {
    ctx.strokeStyle = '#38bdf8';
    ctx.shadowColor = '#38bdf8';
    ctx.beginPath();
    ctx.moveTo(baseX * s, 16 * s);
    const midX = (baseX + phaseVal * 8) * s;
    const footX = (baseX + phaseVal * 16) * s;
    ctx.lineTo(midX, 34 * s);
    ctx.lineTo(footX, 52 * s);
    ctx.stroke();
  };

  drawLeg(28, legFL);
  drawLeg(36, legFR);
  drawLeg(-32, legBL);
  drawLeg(-24, legBR);

  // 4. Queue sinueuse expressive
  ctx.beginPath();
  ctx.moveTo(-44 * s, 4 * s);
  const tailWave = Math.sin(t * 3) * 18 * s;
  ctx.bezierCurveTo(
    -70 * s, -12 * s + tailWave,
    -85 * s, 20 * s - tailWave,
    -100 * s, -20 * s + tailWave
  );
  ctx.stroke();

  // 5. Traînées de particules lumineuses dorées
  ctx.fillStyle = 'rgba(215, 184, 106, 0.6)';
  ctx.shadowColor = '#d7b86a';
  for (let i = 0; i < 6; i++) {
    const px = -60 * s - i * 18 * s + Math.sin(t * 4 + i) * 8 * s;
    const py = Math.cos(t * 3 + i) * 14 * s;
    ctx.beginPath();
    ctx.arc(px, py, (4 - i * 0.5) * s, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Dessine la Baleine bioluminescente ondulante
 */
function renderScenicWhale(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity;

  const t = localTime * clip.motionSpeed;
  const cx = width * (clip.transform.x + Math.sin(t * 0.5) * 0.08);
  const cy = height * (clip.transform.y + Math.cos(t * 0.4) * 0.04);
  const s = clip.transform.scale;

  ctx.translate(cx, cy);

  ctx.shadowColor = '#06b6d4';
  ctx.shadowBlur = 24;
  ctx.strokeStyle = '#06b6d4';
  ctx.lineWidth = 3.5 * s;

  // Corps de baleine stylisé fluide
  ctx.beginPath();
  ctx.moveTo(-90 * s, 0);
  ctx.bezierCurveTo(-50 * s, -38 * s, 60 * s, -34 * s, 90 * s, 0);
  ctx.bezierCurveTo(70 * s, 36 * s, -40 * s, 32 * s, -90 * s, 0);
  ctx.stroke();

  // Nageoire caudale ondulante
  const tailFluke = Math.sin(t * 2) * 14 * s;
  ctx.beginPath();
  ctx.moveTo(-90 * s, 0);
  ctx.lineTo(-125 * s, -26 * s + tailFluke);
  ctx.lineTo(-115 * s, 0);
  ctx.lineTo(-125 * s, 26 * s + tailFluke);
  ctx.closePath();
  ctx.stroke();

  // Nageoire pectorale
  ctx.beginPath();
  ctx.moveTo(10 * s, 12 * s);
  ctx.quadraticCurveTo(20 * s, 46 * s + Math.sin(t * 2) * 10 * s, 0, 48 * s);
  ctx.stroke();

  ctx.restore();
}

/**
 * Effet Slit-Scan temporel : découpage en bandes horizontales décalées
 */
function applySlitScanEffect(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  timeSec: number,
  intensity: number
) {
  const slices = 16;
  const sliceHeight = height / slices;
  const maxShift = width * 0.04 * intensity;

  for (let i = 0; i < slices; i++) {
    const shift = Math.sin(timeSec * 3 + i * 0.6) * maxShift;
    if (Math.abs(shift) > 2) {
      try {
        const sy = i * sliceHeight;
        ctx.drawImage(
          ctx.canvas,
          0, sy, width, sliceHeight,
          shift, sy, width, sliceHeight
        );
      } catch {
        // Safe canvas read/write
      }
    }
  }
}

/**
 * Effet RGB Split / Anaglyphe chromatique pour stéréoscopie scénique
 */
function applyRgbSplitEffect(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  intensity: number,
  isAnaglyph: boolean
) {
  ctx.save();
  const shift = Math.round(width * 0.008 * intensity);

  // Superposition avec décalage rouge / cyan
  ctx.globalCompositeOperation = 'screen';
  ctx.globalAlpha = isAnaglyph ? 0.6 : 0.35;

  ctx.drawImage(ctx.canvas, -shift, 0, width, height);
  ctx.drawImage(ctx.canvas, shift, 0, width, height);

  ctx.restore();
}

/**
 * Danseur Spectral & Pepper's Ghost : silhouette vaporeuse avec résonance optique
 */
function renderScenicDancerGhost(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity * 0.85;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x + Math.sin(t * 0.8) * width * 0.04;
  const cy = height * clip.transform.y;
  const s = clip.transform.scale;

  ctx.translate(cx, cy);
  ctx.shadowColor = 'rgba(226, 232, 240, 0.9)';
  ctx.shadowBlur = 28;

  // Lueur Pepper's Ghost
  ctx.fillStyle = 'rgba(248, 250, 252, 0.25)';
  ctx.beginPath();
  ctx.ellipse(0, -60 * s, 35 * s, 80 * s, Math.sin(t) * 0.15, 0, Math.PI * 2);
  ctx.fill();

  // Silhouette fluide
  ctx.strokeStyle = '#f8fafc';
  ctx.lineWidth = 3 * s;
  ctx.beginPath();
  ctx.moveTo(0, -110 * s); // Tête
  ctx.arc(0, -120 * s, 12 * s, 0, Math.PI * 2);
  ctx.moveTo(0, -108 * s);
  ctx.lineTo(0, -50 * s); // Colonne
  // Bras en arabesque
  ctx.moveTo(0, -90 * s);
  ctx.quadraticCurveTo(-40 * s + Math.cos(t * 1.5) * 15 * s, -80 * s + Math.sin(t) * 20 * s, -65 * s, -110 * s);
  ctx.moveTo(0, -90 * s);
  ctx.quadraticCurveTo(45 * s + Math.sin(t * 1.5) * 15 * s, -70 * s, 60 * s, -40 * s);
  // Jambes
  ctx.moveTo(0, -50 * s);
  ctx.lineTo(-20 * s + Math.sin(t) * 15 * s, 0);
  ctx.moveTo(0, -50 * s);
  ctx.lineTo(25 * s - Math.sin(t) * 15 * s, 0);
  ctx.stroke();

  ctx.restore();
}

/**
 * Pantin de Fils Numérique : marionnette suspendue avec fils verticaux
 */
function renderScenicWirePuppet(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x;
  const cy = height * clip.transform.y;
  const s = clip.transform.scale;

  // Fils verticaux de suspension depuis le cintre
  ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
  ctx.lineWidth = 1;
  [-30 * s, -10 * s, 10 * s, 30 * s].forEach((fx) => {
    ctx.beginPath();
    ctx.moveTo(cx + fx, 0);
    ctx.lineTo(cx + fx + Math.sin(t * 2) * 5 * s, cy - 60 * s);
    ctx.stroke();
  });

  ctx.translate(cx, cy);
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 2.5 * s;
  ctx.shadowColor = '#f59e0b';
  ctx.shadowBlur = 12;

  // Tête
  ctx.beginPath();
  ctx.arc(0, -95 * s, 10 * s, 0, Math.PI * 2);
  ctx.stroke();

  // Croix de marionnette
  const swing = Math.sin(t * 2) * 0.15;
  ctx.rotate(swing);

  // Torse
  ctx.strokeRect(-12 * s, -80 * s, 24 * s, 40 * s);

  // Bras articulés
  ctx.beginPath();
  ctx.moveTo(-12 * s, -75 * s);
  ctx.lineTo(-35 * s, -55 * s + Math.sin(t * 3) * 10 * s);
  ctx.lineTo(-45 * s, -35 * s);
  ctx.moveTo(12 * s, -75 * s);
  ctx.lineTo(35 * s, -55 * s - Math.sin(t * 3) * 10 * s);
  ctx.lineTo(45 * s, -35 * s);
  // Jambes
  ctx.moveTo(-8 * s, -40 * s);
  ctx.lineTo(-14 * s, -15 * s + Math.cos(t * 2) * 8 * s);
  ctx.lineTo(-16 * s, 0);
  ctx.moveTo(8 * s, -40 * s);
  ctx.lineTo(14 * s, -15 * s - Math.cos(t * 2) * 8 * s);
  ctx.lineTo(16 * s, 0);
  ctx.stroke();

  ctx.restore();
}

/**
 * Banc de Méduses Fluorescentes
 */
function renderScenicJellyfish(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x + Math.sin(t * 0.5) * 30;
  const cy = height * clip.transform.y + Math.sin(t * 1.2) * 20;
  const s = clip.transform.scale;

  ctx.translate(cx, cy);
  ctx.shadowColor = '#2dd4bf';
  ctx.shadowBlur = 20;

  // Ombrelle contractile
  const pulse = 1 + Math.sin(t * 2.5) * 0.15;
  ctx.fillStyle = 'rgba(45, 212, 191, 0.35)';
  ctx.strokeStyle = '#2dd4bf';
  ctx.lineWidth = 2 * s;

  ctx.beginPath();
  ctx.arc(0, -20 * s, 35 * s * pulse, Math.PI, 0, false);
  ctx.quadraticCurveTo(0, -10 * s, -35 * s * pulse, -20 * s);
  ctx.fill();
  ctx.stroke();

  // Tentacules ondulants
  ctx.strokeStyle = 'rgba(45, 212, 191, 0.7)';
  ctx.lineWidth = 1.5 * s;
  for (let i = -3; i <= 3; i++) {
    const ox = i * 8 * s * pulse;
    ctx.beginPath();
    ctx.moveTo(ox, -15 * s);
    const wave1 = Math.sin(t * 3 + i) * 12 * s;
    const wave2 = Math.cos(t * 2 + i) * 18 * s;
    ctx.bezierCurveTo(ox + wave1, 20 * s, ox + wave2, 50 * s, ox + wave1, 85 * s);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Nuée d'Oiseaux Lumineux (Boids)
 */
function renderScenicBoids(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x;
  const cy = height * clip.transform.y;
  const count = 18;

  ctx.fillStyle = '#fbbf24';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 14;

  for (let i = 0; i < count; i++) {
    const angle = t * 1.5 + (i * Math.PI * 2) / count;
    const rad = 60 + Math.sin(t * 2 + i) * 35;
    const bx = cx + Math.cos(angle) * rad * clip.transform.scale;
    const by = cy + Math.sin(angle * 1.2) * (rad * 0.5) * clip.transform.scale;

    ctx.save();
    ctx.translate(bx, by);
    ctx.rotate(angle + Math.PI / 2);

    // Dessin d'un boid stylisé (chevron)
    ctx.beginPath();
    ctx.moveTo(0, -6);
    ctx.lineTo(4, 5);
    ctx.lineTo(0, 3);
    ctx.lineTo(-4, 5);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  ctx.restore();
}

/**
 * Brasier Numérique & Braises Scéniques
 */
function renderScenicFireBraziers(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x;
  const cy = height * clip.transform.y;
  const s = clip.transform.scale;

  ctx.translate(cx, cy);
  ctx.shadowColor = '#f97316';
  ctx.shadowBlur = 24;

  // Flammes stylisées superposées
  const colors = ['#ea580c', '#f97316', '#fde047'];
  colors.forEach((col, idx) => {
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.moveTo(-30 * s / (idx + 1), 0);
    const flick = Math.sin(t * 8 + idx * 2) * 10 * s;
    ctx.quadraticCurveTo(
      -25 * s / (idx + 1), -50 * s / (idx + 0.8),
      flick, -80 * s / (idx + 0.9)
    );
    ctx.quadraticCurveTo(
      25 * s / (idx + 1), -50 * s / (idx + 0.8),
      30 * s / (idx + 1), 0
    );
    ctx.closePath();
    ctx.fill();
  });

  // Braises montantes
  ctx.fillStyle = '#fef08a';
  for (let i = 0; i < 8; i++) {
    const pAge = (t * 2 + i * 0.4) % 1;
    const px = Math.sin(i * 12 + t * 4) * 25 * s;
    const py = -pAge * 110 * s;
    const pSize = (1 - pAge) * 3.5 * s;
    ctx.beginPath();
    ctx.arc(px, py, pSize, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Miroir d'Eau & Ondes Réfractives
 */
function renderScenicWaterRipples(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity * 0.8;

  const t = localTime * clip.motionSpeed;
  const cx = width * clip.transform.x;
  const cy = height * clip.transform.y;
  const s = clip.transform.scale;

  ctx.translate(cx, cy);
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1.8 * s;
  ctx.shadowColor = '#38bdf8';
  ctx.shadowBlur = 16;

  // Ondes concentriques en ellipse au sol
  for (let i = 0; i < 4; i++) {
    const waveTime = (t * 0.8 + i * 0.25) % 1;
    const rx = waveTime * 120 * s;
    const ry = rx * 0.35; // Perspective de sol
    const alpha = (1 - waveTime) * 0.9;

    ctx.strokeStyle = `rgba(56, 189, 248, ${alpha})`;
    ctx.beginPath();
    ctx.ellipse(0, 0, Math.max(1, rx), Math.max(1, ry), 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Brume Volumétrique de Plateau
 */
function renderScenicVolumetricFog(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  localTime: number,
  clip: TimelineClip,
  layerOpacity: number
) {
  ctx.save();
  ctx.globalAlpha = clip.transform.opacity * layerOpacity * 0.65;

  const t = localTime * clip.motionSpeed;
  const cy = height * clip.transform.y;

  ctx.fillStyle = 'rgba(203, 213, 225, 0.12)';
  for (let i = 0; i < 5; i++) {
    const fx = ((t * 40 + i * (width / 4)) % (width + 200)) - 100;
    const rad = 70 + Math.sin(t + i) * 20;

    ctx.beginPath();
    ctx.ellipse(fx, cy, rad * 1.6, rad * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * Effet Hydra Feedback Loop
 */
function applyHydraFeedbackEffect(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  timeSec: number,
  intensity: number
) {
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  ctx.globalAlpha = 0.3 * intensity;

  ctx.translate(width / 2, height / 2);
  ctx.rotate(Math.sin(timeSec * 0.5) * 0.02 * intensity);
  ctx.scale(1.02, 1.02);
  ctx.translate(-width / 2, -height / 2);

  try {
    ctx.drawImage(ctx.canvas, 0, 0);
  } catch {}

  ctx.restore();
}

/**
 * Tunnel Infini & Vortex Volumétrique (TouchDesigner / ISF style)
 */
function applyVortexTunnelEffect(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  timeSec: number,
  intensity: number
) {
  ctx.save();
  ctx.globalAlpha = 0.4 * intensity;
  ctx.strokeStyle = '#8b5cf6';
  ctx.lineWidth = 1.5;
  ctx.shadowColor = '#8b5cf6';
  ctx.shadowBlur = 18;

  const cx = width / 2;
  const cy = height * 0.45;
  const rings = 7;

  for (let i = 0; i < rings; i++) {
    const progress = (timeSec * 0.6 + i / rings) % 1;
    const r = progress * (width * 0.45);
    ctx.strokeStyle = `rgba(139, 92, 246, ${(1 - progress) * 0.7})`;
    ctx.beginPath();
    ctx.arc(cx, cy, Math.max(1, r), 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

